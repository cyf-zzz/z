详细请看github.

https://github.com/TryGOTry/CobaltStrike_Cat_4.5

2023.01.13