v2.4

2022.10.19 修复ui显示bug，直接替换客户端jar就行。

v.2.4.1 修复修改主机颜色bug

有bug,请提交git

MD5 (dogcs.jar) = b9bb7623aa630b58343216988c3ecdf1
