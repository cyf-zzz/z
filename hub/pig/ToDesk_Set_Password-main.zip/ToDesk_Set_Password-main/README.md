# 通过bat设置ToDesk安全密码

##  👮🏻‍♀️ 免责声明

由于传播、利用ToDesk_Set_Password工具提供的功能而造成的**任何直接或者间接的后果及损失**，均由使用者本人负责，本人**不为此承担任何责任**。

思路来源：https://docs.todesk.com/zh-CN/command ，官方的操作手册

##  步骤

提示：使用bat之前记得修改ToDesk路径，默认路径为：C:\Program Files (x86)\ToDesk\ToDesk.exe

set_passwd----设置安全密码

set_proxy----设置代理并启用(非必要)

![1.png](/1.png)
